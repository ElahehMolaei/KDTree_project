//Elaheh Molaei : Ferdowsi University of Mashhad - Iran

#include<bits/stdc++.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <sstream> //using for convert a string to a digit 
using namespace std;
//------------------------------------------K--------------------------------------------------------------------------------
const int k=785; //ktree -> k=?
const int n = 10000;
double points[n][k];
const int x = 200;
double p[x][k];
int q[x];
//---------------------------------------node class :  har node motenazer ba ye noghte dar faza ba k ta deray hast------------------------
class Node //har node be ye point ba k ta deraye dar fazaye k bodi eshare mikne
{
	public :
		double point[k]; // tedad deraye haye noghteye point
		Node *left, *right;
		friend Node* newNode(double arr[]);
		friend Node *insertRec(Node *root, double point[], unsigned depth);
		friend Node* insert(Node *root, double point[]);
		friend Node* createtree(double point[n][k]);
		friend bool pointExist(Node* root, double point[]);
};

//-----------------------------------------------------------------------sakhte node jadid ke motanazer ba ye noghte jadid dar faza hast----------------
// A method to create a node of K D tree
Node* newNode(double arr[])
{
	Node* temp = new Node();

	for (int i=0; i<k; i++)
		temp->point[i] = arr[i];

	temp->left = temp->right = NULL;
	return temp;
}
//----------------------------------------------------------------afzoodane node be k tree-----------------------------------------------
// Inserts a new node and returns root of modified tree
// The parameter depth is used to taeine mehvare moghayese
Node *insertRec(Node *root, double point[], unsigned depth) //depth hamooon k baraye point hast
{
	// Tree is empty?
	if (root == NULL)
	return newNode(point);

	// Calculate boode feliye moghayese (cd) of comparison
	unsigned cd = depth % k; 

	// Compare the new point with root on current dimension 'cd'
	// and decide the left or right subtree
	if (point[cd] < (root->point[cd]))
		root->left = insertRec(root->left, point, depth + 1);
	else
		root->right = insertRec(root->right, point, depth + 1);

	return root;
}

// Function to insert a new point with given point in
// KD Tree and return new root. It mainly uses above recursive
// function "insertRec()"
Node* insert(Node *root, double point[])
{
	return insertRec(root, point, 0);
}
Node* createtree(double point[n][k])
{
	Node *root = new Node();
	root = NULL;
	for(int i=0; i<n; i++)
		root = insert(root,point[i]);
	return root;
}
bool arePointsSame(double point1[], double point2[])
{
	// Compare individual pointinate values
	for (int i = 0; i < k; ++i)
		if (point1[i] != point2[i])
			return false;
	return true;
}
bool searchRec(Node* root, double point[], unsigned depth)
{
	// Base cases
	if (root == NULL)
		return false;
	if (arePointsSame(root->point, point))
		return true;

	// Current dimension is computed using current depth and total
	// dimensions (k)
	unsigned cd = depth % k;

	// Compare point with root with respect to cd (Current dimension)
	if (point[cd] < root->point[cd])
		return searchRec(root->left, point, depth + 1);

	return searchRec(root->right, point, depth + 1);
}

// Searches a Point in the K D tree. It mainly uses
// searchRec()
bool pointExist(Node* root, double point[])
{
	// Pass current depth as 0
	return searchRec(root, point, 0);
}
Node *minNode(Node *x, Node *y, Node *z, int d)
{
	Node *res = x;
	if (y != NULL && y->point[d] < res->point[d])
	res = y;
	if (z != NULL && z->point[d] < res->point[d])
	res = z;
	return res;
}

// Recursively finds minimum of d'th dimension in KD tree
// The parameter depth is used to determine current axis.
Node *findMinRec(Node* root, int d, unsigned depth)
{
	// Base cases
	if (root == NULL)
		return NULL;

	// Current dimension is computed using current depth and total
	// dimensions (k)
	unsigned cd = depth % k;

	// Compare point with root with respect to cd (Current dimension)
	if (cd == d)
	{
		if (root->left == NULL)
			return root;
		return findMinRec(root->left, d, depth+1);
	}

	// If current dimension is different then minimum can be anywhere
	// in this subtree
	return minNode(root,
			findMinRec(root->left, d, depth+1),
			findMinRec(root->right, d, depth+1), d);
}

// A wrapper over findMinRec(). Returns minimum of d'th dimension
Node *findMin(Node* root, int d)
{
	// Pass current level or depth as 0
	return findMinRec(root, d, 0);
}

// A utility method to determine if two Points are same
// in K Dimensional space

// Copies point p2 to p1
void copyPoint(double p1[], double p2[])
{
for (int i=0; i<k; i++)
	p1[i] = p2[i];
}

// Function to delete a given point 'point[]' from tree with root
// as 'root'. depth is current depth and passed as 0 initially.
// Returns root of the modified tree.
Node *deleteNodeRec(Node *root, double point[], int depth)
{
	// Given point is not present
	if (root == NULL)
		return NULL;

	// Find dimension of current node
	int cd = depth % k;

	// If the point to be deleted is present at root
	if (arePointsSame(root->point, point))
	{
		// 2.b) If right child is not NULL
		if (root->right != NULL)
		{
			// Find minimum of root's dimension in right subtree
			Node *min = findMin(root->right, cd);

			// Copy the minimum to root
			copyPoint(root->point, min->point);

			// Recursively delete the minimum
			root->right = deleteNodeRec(root->right, min->point, depth+1);
		}
		else if (root->left != NULL) // same as above
		{
			Node *min = findMin(root->left, cd);
			copyPoint(root->point, min->point);
			root->right = deleteNodeRec(root->left, min->point, depth+1);
		}
		else // If node to be deleted is leaf node
		{
			delete root;
			return NULL;
		}
		return root;
	}

	// 2) If current node doesn't contain point, search downward
	if (point[cd] < root->point[cd])
		root->left = deleteNodeRec(root->left, point, depth+1);
	else
		root->right = deleteNodeRec(root->right, point, depth+1);
	return root;
}

// Function to delete a given point from K D Tree with 'root'
Node* deleteNode(Node *root, double point[])
{
// Pass depth as 0
return deleteNodeRec(root, point, 0);
}
//---------------------------------------------------------KNN--------------------------------------------------------
long double distSquared(double p0[], double p1[]) 
{
		long double total = 0;
		int numDims = k; 
		
		for (int i = 0; i < numDims-1; i++) {
			int diff = abs(p0[i]-p1[i]);
			total += pow(diff, 2);
		}		
		return total; 
}
Node* closest(Node* temp,Node* root,double point[])
{
	if (root == NULL) return temp;

	if (temp == NULL) return root;

	    long double d1 = distSquared(root->point, point);
	    long double d2 = distSquared(temp->point, point);

	    if (d1 < d2)
	        return root;
	    else
	        return temp;
}
Node* nearestNeighbor2(Node* root, double point[], int depth)
{
	if(root == NULL)
		return root;
	Node *nextBranch = NULL;
	Node *otherBranch = NULL;
	if(point[depth%k]<root->point[depth%k])
	{
		nextBranch = root->left;
		otherBranch = root->right;
	}
	else
	{
		nextBranch = root->right;
		otherBranch = root->left;
	}
	
	Node *temp = nearestNeighbor2(nextBranch, point, depth+1);
	Node *best = closest(temp,root,point);
	
	long double radiusSquared = distSquared(point,best->point) ; //r;
	long double dist = point[depth] - root->point[depth]; // r'
	
	if (radiusSquared >= dist * dist) {
			temp = nearestNeighbor2(otherBranch, point, depth + 1);
			best = closest(temp, best, point);
		}

		return best;
}
Node* nearestNeighbor1(Node* root, double point[])
{
	return nearestNeighbor2(root, point, 0);
}

double** findmnearest(Node* root, double point[], int m)
{
	Node *r = new Node();
	r = root;
	//cout<<r->left->point[0]<<endl;
	//cout<<r->left->point[1]<<endl;
	double ** arr =  new double*[m];
	for(int i=0;i<m;i++)
	{
		Node *javab = new Node();
		javab = nearestNeighbor1(r,point);
		arr[i] = new double[k];
		for(int j=0; j<k; j++)
		{
			arr[i][j] = javab->point[j];
			//cout<<arr[i][j]<<endl;
		}		
		r = deleteNode(r, javab->point);
	}
	return arr;
}
int findMax(int cluster[], int e)
{
	int max ;
	int t=0;
	max = cluster[0];
	for(int i=0;i<e;i++)
	{
		if(cluster[i]>=max)
		{
			max = cluster[i];
			t = i;
		}
	}
	return t;
}
int classify(double point[], int m, Node* root)
{
	double** a ;
	int cluster[10]={0};
	a = findmnearest(root, point, m);
	for(int i=0;i<m;i++)
	{
	 //a[i][785]=
	 if(a[i][k-1]==0)
	 	cluster[0]++;
	 else if(a[i][k-1]==1)
	 	cluster[1]++;
	 else if(a[i][k-1]==2)
	 	cluster[2]++;
	else if(a[i][k-1]==3)
	 	cluster[3]++;
	else if(a[i][k-1]==4)
	 	cluster[4]++;
	else if(a[i][k-1]==5)
	 	cluster[5]++;
	else if(a[i][k-1]==6)
	 	cluster[6]++;
	else if(a[i][k-1]==7)
	 	cluster[7]++;
	else if(a[i][k-1]==8)
	 	cluster[8]++;
	else if(a[i][k-1]==9)
	 	cluster[9]++;
	}
	return findMax(cluster,10);
}
int* classifyAll(double p[][k],int m, Node* root,int f){
	int* a = new int[f];
	for(int i=0;i<f;i++)
	{
		a[i] = classify(p[i], m, root);
	}
	return a;
}
double accuracy(double p[][k],int m, Node* root,int q[],int f) //q barchasb haye sahih f:tedade noghat   m:k dar KNN moasser dar classifyAll
{
	int* b = new int[f];
	b = classifyAll(p,m,root,f); //pishbini shode tavasote knn
	double count = 0;
	for(int i=0;i<f;i++)
	{
		if(b[i]==q[i])
			count++;
		else
		{
			cout<<" tashkhisi : "<<b[i]<<endl;
			cout<<" truth label : "<<q[i]<<endl;
			cout<<" index :"<<i<<endl;
			cout<<"------------"<<endl;
		}
	//	cout<<"==="<<b[i]<<endl;
	}
	double deqat;
	deqat =  (count/f)*100;
	return deqat;
}
void readfile_noghat(string fname)
{
	fstream file;
	file.open(fname, ios::in);
	int i, j;
	i=0;
	j=0;
	string derayeha="";
	if (!file)
		cout << "No such file";
	else
	{
		char ch;
		while (1)
		{
			file.get(ch);
			if (file.eof())
			{
				break;
			}
			else
			{
				if (ch == ' ')
				{
					stringstream geek(derayeha);
					double digit = 0;
   					geek >> digit;
					points[i][j] = digit;
					derayeha = ""; //NULL
					j++; //784 ta az 0 ta 783 por mishee bode 785 om yanii andise 784 mimoone bara cluster 
				}
				//
				else if (ch == '\n')
				{
					derayeha = ""; //NULL
					i++;
					j=0;
				}
				else
				{
					derayeha+=ch;
				}
				
			}
		}
		file.close();
	}
}
void readfile_cluster(string fname)
{
	fstream file;
	file.open(fname, ios::in);
	int i;
	i=0;
	string derayeha="";
	if (!file)
		cout << "No such file";
	else
	{
		char ch;
		while (1)
		{
			file.get(ch);
			if (file.eof())
			{
				break;
			}
			else
			{
				
				if (ch == '\n')
				{
					stringstream geek(derayeha);
					double digit = 0;
   					geek >> digit;
					points[i][k-1] = digit;//dar point[i][784] mirize 
					derayeha = ""; //NULL 
					i++;
				}
				else
					derayeha+=ch;	
			}
		}
		file.close();
	}
}
void readfile_noghat_test(string fname)
{
	fstream file;
	file.open(fname, ios::in);
	int i, j;
	i=0;
	j=0;
	string derayeha="";
	if (!file)
		cout << "No such file";
	else
	{
		char ch;
		while (1)
		{
			file.get(ch);
			if (file.eof())
			{
				break;
			}
			else
			{
				if (ch == ' ')
				{
					stringstream geek(derayeha);
					double digit = 0;
   					geek >> digit;
					p[i][j] = digit;
					derayeha = ""; //NULL
					j++; //784 ta az 0 ta 783 por mishee bode 785 om yanii andise 784 mimoone bara cluster 
				}
				//
				else if (ch == '\n')
				{
					derayeha = ""; //NULL
					i++;
					j=0;
				}
				else
				{
					derayeha+=ch;
				}
				
			}
		}
		file.close();
	}
}
void readfile_cluster_test(string fname)
{
	fstream file;
	file.open(fname, ios::in);
	int i;
	i=0;
	string derayeha="";
	if (!file)
		cout << "No such file";
	else
	{
		char ch;
		while (1)
		{
			file.get(ch);
			if (file.eof())
			{
				break;
			}
			else
			{
				
				if (ch == '\n')
				{
					stringstream geek(derayeha);
					double digit = 0;
   					geek >> digit;
					q[i] = digit;//dar point[i][784] mirize 
					derayeha = ""; //NULL 
					i++;
				}
				else
					derayeha+=ch;	
			}
		}
		file.close();
	}
}
//----------------------------------------------------------MAIN FUNC----------------------------------------------------------------
int main()
{
	readfile_noghat("noghat.txt"); //kolle noghate 
	readfile_cluster("train.txt"); //clustere kolle noghat
	Node* root = new Node();
	root = NULL;
	for(int i=0;i<n;i++)
	{
		root = insert(root,points[i]);
	}
	/*cout<<endl<<"deraye 47 ome noghteye 389 : "<<points[388][47]<<endl; //must be 189
	cout<<endl<<"deraye 48 ome noghteye 390 : "<<points[389][48]<<endl; //must be 0
	cout<<endl<<"deraye 49 ome noghteye 389 : "<<points[388][49]<<endl; //must be 13
	cout<<endl<<"deraye 74 ome noghteye 389 : "<<points[388][74]<<endl; //must be 85
	cout<<endl<<"cluster noghteye 389 : "<<points[388][784]<<endl; //must be 6
	cout<<endl<<"cluster noghteye 390 : "<<points[389][784]<<endl; //must be 5
	*/
	
	//double p[k];
	//cout<<endl<<"enter the point you wanna to find nearest neighbor :" ;
	//for(int t=0;t<k;t++)
	//	cin>>p[t];
	//cout<<"-----------------"<<endl<<nearestNeighbor1(root, p)->point[0]<<endl;
	//cout<<nearestNeighbor1(root, p)->point[1]<<endl<<"-----------------";
	//int h;
	//cin>>h;
	//findmnearest(root, p, h);
	
	/*cout<<"enter a point you wanna to classify !";
	double p[k];
	for(int t=0;t<k;t++)
		cin>>p[t];
	cout<<endl<<"enter m : ";
	int h;
	cin>>h;
	cout<<endl<<"the cluster is : "<<classify(p, h, root);*/
	/*cout<<"liste shoma chand noghte darad ? ";
	int x;
	cin>>x;
	double p[x][k];
	for(int i=0;i<x;i++)
	{
		for(int j=0;j<k;j++)
		cin>>p[i][j];
	}
	int* b;
	b = classifyAll(p,x,root);
	for(int i=0;i<x;i++)
		cout<<b[i];
	*/
	//cout<<"liste shoma chand noghte darad ? ";
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	readfile_noghat_test("test.txt");
	readfile_cluster_test("testlbls.txt");
	for(int i=0;i<x;i++)
	{
		p[i][k-1]=-1; //inja bejaye cin kardan bia va az file test.txt bekhoon havaset bashe taheshoon -1 bezari 
	}
	cout<<"KNN Enter the K Value!";
	int m; 
	cin>>m; //tooye group goftan m=5 bshe
	double v = accuracy(p,m,root,q,x);
	cout <<"deghate algotithme shoma "<<v<<"% ast"; //bayad 96% bede
	/*for(int i=0;i<x;i++)
	{
		cout<<i+1<<" : "<<q[i]<<endl;
	}*/
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	return 0;
}
